# -*- coding: utf-8 -*-
"""
Created on Thu Feb  5 09:30:23 2026

@author: Priyangan
"""


name = input(("Enter your Name?"))
hours = float(input("Enter your working hours per week?"))


hourly_wage = 22
standard_hours = 40
extra_pay = 1.5 * hourly_wage
extra_hours = hours - standard_hours
extra_pay = extra_hours * 1.5 * 22
standard_pay = 40 * hourly_wage
total_pay = standard_pay + extra_pay

if hours <= 40:
    print("Your salary is:", hours * hourly_wage)
else:
    print("Your salary is:",extra_pay + standard_pay)
    
    
    



