# -*- coding: utf-8 -*-
"""
Created on Thu Feb 12 10:28:13 2026

@author: Priyangan
"""

attempts=1

while (True):
    
    password=input("Enter Your Password here:")
    
    if password== "test100":
        print("You are logged in!")
        break
    else:
        print("Wrong Password")
        
        attempts=attempts+1
    if attempts>=5:
        print("You’ve reached the maximum logon attempts!")
        break
    
    
    
    
    