# -*- coding: utf-8 -*-
"""
Created on Thu Feb 12 09:10:29 2026

@author: Priyangan
"""

name=input("Enter your Name:")
balance=1000 
op=True

while True:
    print("~~~~MENU~~~~")
    print("1.DEPOSIT")
    print("2.WITHDRAWAL")
    print("3.OBTAIN A BALANCE")
    print("4.QUIT")
    
    choose=int(input("Enter the value of the service: "))
    
    if choose==1:
        amount=int(input("Enter your Deposit Amount:"))
        balance=balance+amount
        print(balance)
        break
    elif choose == 2:
        amount=int(input("Enter the Withdrawal Value:"))
        if amount>balance:
            print("It is not possible to withdraw beyond the account balance")
        else:
           balance=balance-amount
           print(balance)
        break
    elif choose == 3:
        print(balance)
        break
        op=True
    else: 
        print("Thanks for choosing us as your bank, Visit us again!")
        break
        